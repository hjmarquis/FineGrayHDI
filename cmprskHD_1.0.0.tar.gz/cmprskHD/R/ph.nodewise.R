ph.nodewise=function(x,y,ftime=NULL,fstatus=NULL,id=1:nrow(x),family=c("cox","finegray"),
                     weights,offset=NULL,...)
{

}
